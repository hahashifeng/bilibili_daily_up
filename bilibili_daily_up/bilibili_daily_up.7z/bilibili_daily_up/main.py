'''
Author: ForMemRs
Date: 2022-06-19 17:39:18
LastEditors: ForMemRS
LastEditTime: 2022-07-17 00:30:49
FilePath: /bilibili_daily/main.py
Blog: https://www.52pojie.cn/?1507943
Copyright (c) 2022 by ForMemRs, All Rights Reserved.
'''


from bilibili import Bilibili


if __name__ == '__main__':
    bilibili = Bilibili()
    bilibili.go()
