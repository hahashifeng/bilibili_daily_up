'''
Author: ForMemRS
Date: 2022-07-16 19:31:02
LastEditors: ForMemRS
LastEditTime: 2022-07-16 19:31:21
FilePath: /bilibili_daily/api.py
Blog: https://www.52pojie.cn/?1507943
Copyright (c) 2022 by ForMemRs, All Rights Reserved. 
'''


info_url = 'http://api.bilibili.com/x/space/myinfo'
coin_url = 'http://account.bilibili.com/site/getCoin'
inquire_url = 'https://api.bilibili.com/x/member/web/exp/reward'
get_video_list_url = 'https://api.bilibili.com/x/space/arc/search?mid={}'
watch_video_url = 'https://api.bilibili.com/x/click-interface/web/heartbeat'
share_video_url = 'https://api.bilibili.com/x/web-interface/share/add'
insert_coins_url = 'https://api.bilibili.com/x/web-interface/coin/add'
live_sign_url = 'https://api.live.bilibili.com/xlive/web-ucenter/v1/sign/DoSign'
live_info_url = 'https://api.live.bilibili.com/xlive/web-ucenter/user/get_user_info'
silver2coin_url = 'https://api.live.bilibili.com/xlive/revenue/v1/wallet/silver2coin'


